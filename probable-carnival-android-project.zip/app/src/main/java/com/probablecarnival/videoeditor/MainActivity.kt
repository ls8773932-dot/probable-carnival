package com.probablecarnival.videoeditor

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

@UnstableApi
class MainActivity : AppCompatActivity() {
    private var selectedUri: Uri? = null
    private var player: ExoPlayer? = null
    private lateinit var playerView: PlayerView
    private lateinit var statusText: TextView
    private lateinit var startInput: EditText
    private lateinit var endInput: EditText
    private lateinit var exportButton: Button
    private var transformer: Transformer? = null

    private val videoPicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            selectedUri = uri
            playVideo(uri)
            statusText.text = "वीडियो चुना गया। शुरुआत और समाप्ति समय सेकंड में भरें।"
            exportButton.isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }

        val heading = TextView(this).apply {
            text = "Probable Carnival Video Editor"
            textSize = 22f
        }
        root.addView(heading)

        val subtitle = TextView(this).apply {
            text = "वीडियो चुनें • Preview देखें • Clip export करें"
            textSize = 15f
            setPadding(0, 8, 0, 16)
        }
        root.addView(subtitle)

        val pickButton = Button(this).apply {
            text = "मोबाइल से वीडियो चुनें"
            setOnClickListener { videoPicker.launch("video/*") }
        }
        root.addView(pickButton)

        playerView = PlayerView(this)
        root.addView(playerView, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(220)
        ))

        startInput = EditText(this).apply {
            hint = "शुरुआत (सेकंड), जैसे 0"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText("0")
        }
        root.addView(startInput)

        endInput = EditText(this).apply {
            hint = "समाप्ति (सेकंड), जैसे 15"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setText("15")
        }
        root.addView(endInput)

        exportButton = Button(this).apply {
            text = "Clip Export करें"
            isEnabled = false
            setOnClickListener { exportClip() }
        }
        root.addView(exportButton)

        statusText = TextView(this).apply {
            text = "शुरू करने के लिए वीडियो चुनें।"
            textSize = 14f
            setPadding(0, 12, 0, 0)
        }
        root.addView(statusText)

        setContentView(root)
    }

    private fun playVideo(uri: Uri) {
        player?.release()
        player = ExoPlayer.Builder(this).build().also { exo ->
            playerView.player = exo
            exo.setMediaItem(MediaItem.fromUri(uri))
            exo.prepare()
            exo.playWhenReady = false
        }
    }

    private fun exportClip() {
        val uri = selectedUri ?: return
        val startMs = (startInput.text.toString().toDoubleOrNull() ?: 0.0).times(1000).toLong()
        val endMs = (endInput.text.toString().toDoubleOrNull() ?: 15.0).times(1000).toLong()

        if (startMs < 0 || endMs <= startMs) {
            Toast.makeText(this, "समाप्ति समय, शुरुआत से बड़ा होना चाहिए।", Toast.LENGTH_LONG).show()
            return
        }

        val outputDir = getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES)
        if (outputDir == null) {
            statusText.text = "Export folder उपलब्ध नहीं है।"
            return
        }
        val outputFile = File(outputDir, "clip_${System.currentTimeMillis()}.mp4")
        statusText.text = "Export शुरू हो रहा है…"
        exportButton.isEnabled = false

        val clippedMediaItem = MediaItem.Builder()
            .setUri(uri)
            .setClippingConfiguration(
                MediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(startMs)
                    .setEndPositionMs(endMs)
                    .build()
            )
            .build()

        val editedItem = EditedMediaItem.Builder(clippedMediaItem).build()
        transformer = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    runOnUiThread {
                        statusText.text = "Export पूरा हुआ!\nफाइल: ${outputFile.absolutePath}\nयह ऐप के निजी Movies फ़ोल्डर में सेव है।"
                        exportButton.isEnabled = true
                    }
                }

                override fun onError(
                    composition: androidx.media3.transformer.Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    runOnUiThread {
                        statusText.text = "Export में समस्या: ${exportException.message}"
                        exportButton.isEnabled = true
                    }
                }
            })
            .build()

        transformer?.start(editedItem, outputFile.absolutePath)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onStop() {
        super.onStop()
        player?.release()
        player = null
        playerView.player = null
    }

    override fun onDestroy() {
        transformer?.cancel()
        super.onDestroy()
    }
}
