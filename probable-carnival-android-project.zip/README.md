# Probable Carnival Video Editor

यह Android का शुरुआती वीडियो एडिटर प्रोजेक्ट है।

## अभी उपलब्ध सुविधाएँ
- मोबाइल से वीडियो चुनना
- वीडियो preview करना
- शुरुआत और समाप्ति समय (सेकंड) देकर clip export करना
- MP4 output बनाना

## मोबाइल से APK कैसे बनाएँ
1. इस project की सभी files को अपनी GitHub repository `probable-carnival` में upload करें।
2. GitHub repository में **Actions** टैब खोलें।
3. अगर workflow पहली बार चलाने की अनुमति माँगे, तो उसे enable करें।
4. **Build Android APK** workflow खोलें और **Run workflow** दबाएँ (या `main` पर push के बाद build अपने-आप चलेगा)।
5. सफल run के बाद नीचे **Artifacts** में `probable-carnival-debug-apk` डाउनलोड करें।
6. ZIP खोलकर `app-debug.apk` निकालें और अपने Android फोन पर install करें। फोन की अनुमति माँगने पर केवल भरोसेमंद build के लिए install की अनुमति दें।

## महत्वपूर्ण
यह शुरुआती MVP है, CapCut जैसा पूर्ण editor नहीं। Export की शुरुआत/समाप्ति समय वीडियो की अवधि के भीतर रखें। फिलहाल output ऐप के निजी Movies folder में सेव होता है; अगली iteration में Gallery/Downloads में save/share विकल्प जोड़ा जा सकता है।
